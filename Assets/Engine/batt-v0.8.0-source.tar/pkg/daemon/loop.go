package daemon

import (
	"reflect"
	"sync"
	"time"

	"github.com/sirupsen/logrus"

	"github.com/charlie0129/batt/pkg/calibration"
	"github.com/charlie0129/batt/pkg/compatibility"
	"github.com/charlie0129/batt/pkg/config"
	"github.com/charlie0129/batt/pkg/smc"
)

var (
	maintainedChargingInProgress = false
	maintainLoopInnerLock        = &sync.Mutex{}
	// wg is used to skip several loops when system woke up or before sleep
	wg                      = &sync.WaitGroup{}
	loopInterval            = time.Duration(10) * time.Second
	loopRecorder            = NewTimeSeriesRecorder(60)
	continuousLoopThreshold = 1*time.Minute + 20*time.Second // add 20s to be sure
)

// infiniteLoop runs forever and maintains the battery charge,
// which is called by the daemon.
func infiniteLoop() {
	for {
		now := time.Now()
		if restoreDisabledLimit(conf, now) {
			maintainLoopForced()
		}
		if capabilities.AdapterControl {
			maintainAdapterDisable(conf, now)
		}
		maintainLoop()
		time.Sleep(loopInterval)
	}
}

// maintainAdapterDisable keeps a temporary adapter disable active across
// daemon restarts and enables the adapter once its deadline has passed. It
// reports whether an expired schedule was completed.
func maintainAdapterDisable(conf config.Config, now time.Time) bool {
	chargeControlTransitionMu.Lock()
	defer chargeControlTransitionMu.Unlock()

	until := conf.AdapterDisableUntil()
	if until.IsZero() {
		return false
	}
	// Calibration owns the adapter throughout its workflow and restores its
	// snapshot on completion or cancellation. Keep the timer pending until then.
	if calibrationOwnsChargeLimit() {
		return false
	}

	enabled, err := smcIsAdapterEnabled()
	if err != nil {
		logrus.WithError(err).Error("failed to check power adapter for temporary disable")
		return false
	}

	if now.Before(until) {
		if enabled {
			if err := smcDisableAdapter(); err != nil {
				logrus.WithError(err).Error("failed to maintain temporary power adapter disable")
			}
		}
		return false
	}

	if !enabled {
		if err := smcEnableAdapter(); err != nil {
			logrus.WithError(err).Error("failed to enable power adapter after temporary disable")
			return false
		}
	}
	conf.ClearAdapterDisableTimer()
	if err := conf.Save(); err != nil {
		logrus.Errorf("saveConfig failed: %v", err)
	}
	logrus.Info("adapter disable duration elapsed, power adapter enabled")
	return true
}

// restoreDisabledLimit restores the upper limit saved by a "batt disable --for"
// once its deadline has passed. It reports whether the limit was restored.
func restoreDisabledLimit(conf config.Config, now time.Time) bool {
	chargeControlTransitionMu.Lock()
	defer chargeControlTransitionMu.Unlock()

	until := conf.DisableUntil()
	if until.IsZero() || now.Before(until) {
		return false
	}

	// Calibration force-writes the upper limit it snapshotted when it finishes,
	// which would silently undo the restore. This also resolves persisted
	// conflicts after a daemon restart: calibration keeps ownership and the
	// timer remains pending until calibration finishes or is cancelled.
	if calibrationOwnsChargeLimit() {
		return false
	}

	limit := conf.PreDisableLimit()
	conf.ClearDisableTimer()

	if limit < 10 || limit > 100 {
		logrus.Warnf("invalid saved charge limit %d%%, not restoring", limit)
		if err := conf.Save(); err != nil {
			logrus.Errorf("saveConfig failed: %v", err)
		}
		return false
	}

	conf.SetUpperLimit(limit)
	if err := conf.Save(); err != nil {
		logrus.Errorf("saveConfig failed: %v", err)
	}

	logrus.WithField("limit", limit).Infof("disable duration elapsed, charge limit restored")

	return true
}

// checkMissedMaintainLoops checks if there are too many missed maintain loops,
// which could indicate that the system was in sleep mode or there is some issue
// with the maintain loop execution.
// It returns true if there are too many missed loops.
func checkMissedMaintainLoops(logStatus bool) bool {
	maintainLoopCount := loopRecorder.GetRecordsIn(continuousLoopThreshold)
	expectedMaintainLoopCount := int(continuousLoopThreshold / loopInterval)
	minMaintainLoopCount := expectedMaintainLoopCount - 1
	relativeTimes := loopRecorder.GetLastRecords(continuousLoopThreshold)

	if maintainLoopCount < minMaintainLoopCount {
		if logStatus {
			logrus.WithFields(logrus.Fields{
				"maintainLoopCount":         maintainLoopCount,
				"expectedMaintainLoopCount": expectedMaintainLoopCount,
				"minMaintainLoopCount":      minMaintainLoopCount,
				"recentRecords":             formatRelativeTimes(relativeTimes),
			}).Infof("Possibly missed maintain loop")
		}

		return true
	}

	// Another loopInterval is added to the threshold so we can get
	// loop counts greater than minMaintainLoopCount, so we only print
	// once when the maintain loop is stabilized, instead of printing
	// every time when maintainLoopCount == minMaintainLoopCount (always
	// this case if using maintainLoopCount), which could be very spammy.
	if loopRecorder.GetRecordsIn(continuousLoopThreshold+loopInterval) == minMaintainLoopCount {
		if logStatus {
			logrus.WithFields(logrus.Fields{
				"maintainLoopCount":         maintainLoopCount,
				"expectedMaintainLoopCount": expectedMaintainLoopCount,
				"minMaintainLoopCount":      minMaintainLoopCount,
				"recentRecords":             formatRelativeTimes(relativeTimes),
			}).Infof("Maintain loop has been stabilized")
		}
	}

	return false
}

// maintainLoop maintains the battery charge. It has the logic to
// prevent parallel runs. So if one maintain loop is already running,
// the next one will need to wait until the first one finishes.
func maintainLoop() bool {
	if capabilities.ChargeControlMode != compatibility.ChargeControlLegacy {
		return maintainLoopForced()
	}

	defer loopRecorder.AddRecordNow()

	if conf.PreventSystemSleep() {
		// No need to keep track missed loops and wait post/before sleep delays, since
		// prevent-system-sleep would prevent unexpected sleep during charging.
		return maintainLoopInner(true)
	}

	// See wg.Add() in sleepcallback.go for why we need to wait.
	tsBeforeWait := time.Now()
	wg.Wait()
	tsAfterWait := time.Now()
	if tsAfterWait.Sub(tsBeforeWait) > time.Second*1 {
		logrus.Debugf("this maintain loop waited %d seconds after being initiated, now ready to execute", int(tsAfterWait.Sub(tsBeforeWait).Seconds()))
	}

	// just log status, not doing anything, yet
	_ = checkMissedMaintainLoops(true)

	// Missed-loop protection is the fallback for sleep transitions where macOS
	// did not deliver a sleep notification. Disabling charging in that case is
	// part of DisableChargingPreSleep's behavior, so honor the user's choice to
	// let charging continue while the system is asleep.
	return maintainLoopInner(!conf.DisableChargingPreSleep())
}

// maintainLoopForced maintains the battery charge. It runs without waiting
// for post/pre sleep delays, but yet has logic to prevent parallel runs.
// It is mainly called by the HTTP APIs.
func maintainLoopForced() bool {
	return maintainLoopInner(true)
}

func handleNoMaintain(isChargingEnabled bool) bool {
	if !isChargingEnabled {
		logrus.Debug("limit set to 100%, but charging is disabled, enabling")
		err := smcConn.EnableCharging()
		if err != nil {
			logrus.Errorf("EnableCharging failed: %v", err)
			return false
		}

		if smcConn.CheckMagSafeExistence() {
			switch conf.ControlMagSafeLED() {
			case config.ControlMagSafeModeAlwaysOff:
				err := smcConn.DisableMagSafeLed()
				if err != nil {
					// no fail
					logrus.Errorf("DisableMagSafeLed failed: %v", err)
				}
			default:
				// Reset MagSafe LED to system state.
				err = smcConn.SetMagSafeLedState(smc.LEDSystem)
				if err != nil {
					// no fail
					logrus.Errorf("SetMagSafeLedState(LEDSystem) failed: %v", err)
				}
			}
		}
	}

	if smcConn.CheckMagSafeExistence() {
		// Set MagSafe LED according to config.
		currentMagSafeLEDState, err := smcConn.GetMagSafeLedState()
		if err != nil {
			// no fail
			logrus.Errorf("GetMagSafeLedState failed: %v", err)
		}
		switch conf.ControlMagSafeLED() {
		case config.ControlMagSafeModeAlwaysOff:
			if currentMagSafeLEDState != smc.LEDOff {
				err := smcConn.DisableMagSafeLed()
				if err != nil {
					// no fail
					logrus.Errorf("DisableMagSafeLed failed: %v", err)
				}
			}
		default:
			// This applies to both ControlMagSafeModeEnabled and ControlMagSafeModeDisabled
			// modes. Because in Disabled mode we should not interfere with the LED state,
			// in Enabled mode we want to show the system state (which is the same as
			// apple's default behavior when limit=100%).
			if currentMagSafeLEDState != smc.LEDSystem {
				err := smcConn.SetMagSafeLedState(smc.LEDSystem)
				if err != nil {
					// no fail
					logrus.Errorf("SetMagSafeLedState(LEDSystem) failed: %v", err)
				}
			}
		}
	}

	// Calling this multiple times is no-op.
	err := AllowSleepOnAC()
	if err != nil {
		logrus.Errorf("AllowSleepOnAC failed: %v", err)
	}

	cancelCalibrationForPermanentDisable()

	maintainedChargingInProgress = false
	return true
}

func cancelCalibrationForPermanentDisable() {
	// A persisted temporary-disable/calibration conflict can be loaded after a
	// restart. Calibration is restored paused for safety, so keep it intact and
	// let the disable timer wait for the user to resume or cancel calibration.
	if !conf.DisableUntil().IsZero() {
		return
	}
	cancelCalibrationNoRestoreNoError()
}

func handleChargingLogic(ignoreMissedLoops, isChargingEnabled, isPluggedIn bool, batteryCharge, lower, upper int) bool {
	maintainLoopsMissed := !ignoreMissedLoops && checkMissedMaintainLoops(false)

	// Fix for #123.
	// Consider this case:
	//   1. charging is enabled (batteryCharge < lower)
	//   2. batt execution is interrupted constantly (maintain loop is executed with unexpected interval), the maintain loop is missed for some reason (macOS didn't send a sleep notification)
	//   3. batt could not disable charging in-time because it's constantly interrupted, and the battery keeps charging, which could cause overcharging.
	//
	// In this case, we can stop charging immediately when we detect that
	// there are too many missed maintain loops, even if the battery charge is
	// below the lower limit, to prevent overcharging.
	if isChargingEnabled && maintainLoopsMissed {
		logrus.WithFields(logrus.Fields{
			"batteryCharge": batteryCharge,
			"lower":         lower,
			"upper":         upper,
		}).Infof("Too many missed maintain loops detected while charging is enabled. Disabling charging to prevent overcharging.")
		err := smcConn.DisableCharging()
		if err != nil {
			logrus.Errorf("DisableCharging failed: %v", err)
			return false
		}
		isChargingEnabled = false
		maintainedChargingInProgress = false
	}

	// Should enable charging.
	if batteryCharge < lower && !isChargingEnabled {
		// If there are too many missed maintain loops, it could indicate that
		// the system was in sleep mode, or macOS interrupted executing the
		// maintain loop for some reason, or system has just woken up.
		// In this case, we should wait until the maintain loops are stable
		// before enabling charging, to avoid enabling charging when the
		// system is in sleep mode, which could overcharge.
		if !ignoreMissedLoops && maintainLoopsMissed {
			logrus.WithFields(logrus.Fields{
				"batteryCharge": batteryCharge,
				"lower":         lower,
				"upper":         upper,
			}).Infof("Battery charge is below lower limit, but too many missed maintain loops are missed. Will wait until maintain loops are stable")
			return true
		}

		logrus.WithFields(logrus.Fields{
			"batteryCharge": batteryCharge,
			"lower":         lower,
			"upper":         upper,
		}).Infof("Battery charge is below lower limit, enabling charging")
		err := smcConn.EnableCharging()
		if err != nil {
			logrus.Errorf("EnableCharging failed: %v", err)
			return false
		}
		isChargingEnabled = true
		maintainedChargingInProgress = true
	}

	// Should disable charging.
	if batteryCharge >= upper && isChargingEnabled {
		logrus.WithFields(logrus.Fields{
			"batteryCharge": batteryCharge,
			"lower":         lower,
			"upper":         upper,
		}).Infof("Battery charge is above upper limit, disabling charging")
		err := smcConn.DisableCharging()
		if err != nil {
			logrus.Errorf("DisableCharging failed: %v", err)
			return false
		}
		isChargingEnabled = false
		maintainedChargingInProgress = false
	}

	switch conf.ControlMagSafeLED() {
	case config.ControlMagSafeModeAlwaysOff:
		_ = smcConn.DisableMagSafeLed()
	case config.ControlMagSafeModeEnabled:
		updateMagSafeLed(isChargingEnabled)
	default:
		// nothing
	}

	if conf.PreventSystemSleep() {
		if isChargingEnabled {
			err := PreventSleepOnAC()
			if err != nil {
				logrus.Errorf("PreventSleepOnAC failed: %v", err)
			}
		} else {
			err := AllowSleepOnAC()
			if err != nil {
				logrus.Errorf("AllowSleepOnAC failed: %v", err)
			}
		}
	}

	// batteryCharge >= upper - delta && batteryCharge < upper
	// do nothing, keep as-is

	return true
}

func maintainLoopInner(ignoreMissedLoops bool) bool {
	maintainLoopInnerLock.Lock()
	defer maintainLoopInnerLock.Unlock()

	switch capabilities.ChargeControlMode {
	case compatibility.ChargeControlFirmware:
		return maintainFirmwareChargeLimit()
	case compatibility.ChargeControlLegacy:
		return maintainLegacyCharging(ignoreMissedLoops)
	default:
		maintainedChargingInProgress = false
		return false
	}
}

// maintainFirmwareChargeLimit delegates hysteresis enforcement to the
// firmware. It deliberately does not read battery/charging state or interact
// with sleep, MagSafe, adapter, or calibration features.
func maintainFirmwareChargeLimit() bool {
	if calibrationNeedsMaintainLoop() {
		batteryCharge, err := smcConn.GetBatteryCharge()
		if err != nil {
			logrus.Errorf("GetBatteryCharge failed during calibration: %v", err)
			return false
		}
		if applyCalibrationWithinLoop(batteryCharge) {
			return true
		}
	}

	upper := conf.UpperLimit()
	if upper >= 100 {
		changed, err := smcConn.EnsureFirmwareChargeLimitDisabled()
		if err != nil {
			logrus.Errorf("failed to deactivate firmware charge limit: %v", err)
			return false
		}
		if changed {
			logrus.Info("deactivated firmware charge limit")
		}
		maintainedChargingInProgress = false
		return true
	}

	lower := conf.LowerLimit()
	changed, err := smcConn.EnsureFirmwareChargeLimit(lower, upper)
	if err != nil {
		logrus.Errorf("failed to reconcile firmware charge limit: %v", err)
		return false
	}
	if changed {
		logrus.WithFields(logrus.Fields{"lower": lower, "upper": upper}).Info("reconciled firmware charge limit")
	} else {
		logrus.WithFields(logrus.Fields{"lower": lower, "upper": upper}).Trace("firmware charge limit is correct")
	}
	maintainedChargingInProgress = false
	return true
}

// maintainLegacyCharging contains the original batt-managed charge loop.
func maintainLegacyCharging(ignoreMissedLoops bool) bool {

	upper := conf.UpperLimit()
	lower := conf.LowerLimit()
	maintain := upper < 100

	isChargingEnabled, err := smcConn.IsChargingEnabled()
	if err != nil {
		logrus.Errorf("IsChargingEnabled failed: %v", err)
		return false
	}

	// Always get current battery charge to possibly drive calibration first.
	batteryCharge, err := smcConn.GetBatteryCharge()
	if err != nil {
		logrus.Errorf("GetBatteryCharge failed: %v", err)
		return false
	}

	isPluggedIn, err := smcConn.IsPluggedIn()
	if err != nil {
		logrus.Errorf("IsPluggedIn failed: %v", err)
		return false
	}

	maintainedChargingInProgress = isChargingEnabled && isPluggedIn && calibrationState.Phase == calibration.PhaseIdle
	printStatus(batteryCharge, lower, upper, isChargingEnabled, isPluggedIn, maintainedChargingInProgress, calibrationState.Phase != calibration.PhaseIdle)

	// If calibration is active, advance it and skip normal maintain logic.
	if applyCalibrationWithinLoop(batteryCharge) {
		switch conf.ControlMagSafeLED() {
		case config.ControlMagSafeModeAlwaysOff:
			_ = smcConn.DisableMagSafeLed()
		case config.ControlMagSafeModeEnabled:
			updateMagSafeLed(isChargingEnabled)
		default:
			// nothing
		}
		return true
	}

	// If maintain is disabled, we don't care about the battery charge, enable charging anyway.
	if !maintain {
		return handleNoMaintain(isChargingEnabled)
	}

	return handleChargingLogic(ignoreMissedLoops, isChargingEnabled, isPluggedIn, batteryCharge, lower, upper)
}

func updateMagSafeLed(isChargingEnabled bool) {
	err := smcConn.SetMagSafeCharging(isChargingEnabled)
	if err != nil {
		logrus.Errorf("SetMagSafeCharging failed: %v", err)
	}
}

var lastPrintTime time.Time

type loopStatus struct {
	batteryCharge                int
	lower                        int
	upper                        int
	isChargingEnabled            bool
	isPluggedIn                  bool
	maintainedChargingInProgress bool
	calibrationInProgress        bool
}

var lastStatus loopStatus

func printStatus(
	batteryCharge int,
	lower int,
	upper int,
	isChargingEnabled bool,
	isPluggedIn bool,
	maintainedChargingInProgress bool,
	calibrationInProgress bool,
) {
	currentStatus := loopStatus{
		batteryCharge:                batteryCharge,
		lower:                        lower,
		upper:                        upper,
		isChargingEnabled:            isChargingEnabled,
		isPluggedIn:                  isPluggedIn,
		maintainedChargingInProgress: maintainedChargingInProgress,
		calibrationInProgress:        calibrationInProgress,
	}

	fields := logrus.Fields{
		"batteryCharge":                batteryCharge,
		"lower":                        lower,
		"upper":                        upper,
		"chargingEnabled":              isChargingEnabled,
		"isPluggedIn":                  isPluggedIn,
		"maintainedChargingInProgress": maintainedChargingInProgress,
		"calibrationInProgress":        calibrationInProgress,
	}

	defer func() { lastPrintTime = time.Now() }()

	// Skip printing if the last print was less than loopInterval+1 seconds ago and everything is the same.
	if time.Since(lastPrintTime) < loopInterval+time.Second && reflect.DeepEqual(lastStatus, currentStatus) {
		logrus.WithFields(fields).Trace("status")
		return
	}

	logrus.WithFields(fields).Debug("status")

	lastStatus = currentStatus
}
