package main

import (
	"errors"
	"fmt"
	"net/http"
	_ "net/http/pprof"
	"os"
	"path"
	"runtime"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"golang.org/x/term"

	"github.com/charlie0129/batt/pkg/client"
	"github.com/charlie0129/batt/pkg/compatibility"
	"github.com/charlie0129/batt/pkg/gui"
	"github.com/charlie0129/batt/pkg/utils/osver"
)

var (
	logLevel       = "info"
	unixSocketPath = "/var/run/batt.sock"
	configPath     = "/etc/batt.json"
	pprofAddr      = ""
)

var (
	gBasic        = "Basic:"
	gAdvanced     = "Advanced:"
	gInstallation = "Installation:"
	commandGroups = []string{
		gBasic,
		gAdvanced,
	}
)

var apiClient *client.Client
var clientCapabilities = compatibility.Permissive()

const capabilityAnnotation = "batt.requires-capability"

const helpCompatibilityTimeout = 500 * time.Millisecond

func annotateCapability(cmd *cobra.Command, feature compatibility.Feature) *cobra.Command {
	if cmd.Annotations == nil {
		cmd.Annotations = make(map[string]string)
	}
	cmd.Annotations[capabilityAnnotation] = string(feature)
	return cmd
}

func requiredCapability(cmd *cobra.Command) (compatibility.Feature, bool) {
	for current := cmd; current != nil; current = current.Parent() {
		if value, ok := current.Annotations[capabilityAnnotation]; ok {
			return compatibility.Feature(value), true
		}
	}
	return "", false
}

func hideUnsupportedCommands(root *cobra.Command, capabilities compatibility.Capabilities) {
	for _, cmd := range root.Commands() {
		if feature, required := requiredCapability(cmd); required {
			cmd.Hidden = !capabilities.Supports(feature)
		}
		hideUnsupportedCommands(cmd, capabilities)
	}
}

func capabilitiesForHelp() compatibility.Capabilities {
	fallback := compatibility.Permissive()
	detected, err := client.NewClientWithTimeout(unixSocketPath, helpCompatibilityTimeout).GetCompatibility()
	if err != nil {
		return fallback
	}
	return *detected
}

func setupLogger() error {
	level, err := logrus.ParseLevel(logLevel)
	if err != nil {
		return fmt.Errorf("failed to parse log level: %v", err)
	}
	logrus.SetLevel(level)
	logrus.SetFormatter(&logrus.TextFormatter{})
	if term.IsTerminal(int(os.Stderr.Fd())) {
		logrus.SetFormatter(&logrus.TextFormatter{
			FullTimestamp:   true,
			TimestampFormat: time.Kitchen,
		})
	}

	return nil
}

func handleCmdError(err error) {
	if errors.Is(err, client.ErrDaemonNotRunning) {
		fmt.Fprintln(os.Stderr, "\nError: batt daemon is not running")
		fmt.Fprintln(os.Stderr, "Is the daemon running? Have you installed it?")
	} else if errors.Is(err, client.ErrPermissionDenied) {
		fmt.Fprintln(os.Stderr, "\nError: Permission Denied")
		fmt.Fprintln(os.Stderr, "  - Try running the command again with 'sudo'")
		fmt.Fprintln(os.Stderr, "  - Or reinstall the daemon with the '--allow-non-root-access' flag to grant permissions to your user")
	}
}

func main() {
	// Reduce the number of CPUs used by the batt.
	// batt does not need to use much.
	if os.Getenv("GOMAXPROCS") == "" {
		runtime.GOMAXPROCS(2)
	}
	runtime.LockOSThread()

	if !osver.IsAtLeast(11, 0, 0) {
		fmt.Fprintln(os.Stderr, "batt requires macOS 11.0 or later")
		os.Exit(1)
	}

	// Start pprof server if enabled
	if pprofAddr != "" {
		go func() {
			logrus.Infof("Starting pprof server on %s", pprofAddr)
			if err := http.ListenAndServe(pprofAddr, nil); err != nil {
				logrus.Errorf("Failed to start pprof server: %v", err)
			}
		}()
	}

	cmd := NewCommand()
	if err := cmd.Execute(); err != nil {
		handleCmdError(err)
		os.Exit(1)
	}
}

func NewCommand() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "batt",
		Short: "batt is a tool to control battery charging on Apple Silicon MacBooks",
		Long: `batt is a tool to control battery charging on Apple Silicon MacBooks.

Website: https://github.com/charlie0129/batt
Report issues: https://github.com/charlie0129/batt/issues`,
		SilenceUsage: true,
		PersistentPreRunE: func(selected *cobra.Command, _ []string) error {
			err := setupLogger()
			if err != nil {
				return err
			}

			apiClient = client.NewClient(unixSocketPath)
			clientCapabilities = compatibility.Permissive()
			if detected, err := apiClient.GetCompatibility(); err == nil {
				clientCapabilities = *detected
			} else {
				// An absent daemon or an older daemon without this endpoint must
				// not prevent commands from running.
				logrus.WithError(err).Debug("detailed compatibility unavailable; enabling all client features")
			}

			if clientVersion, daemonVersion, err := getVersion(); err == nil {
				if daemonVersion != clientVersion {
					logrus.WithFields(logrus.Fields{
						"clientVersion": clientVersion,
						"daemonVersion": daemonVersion,
					}).Warn("Version mismatch between client and daemon. batt may not work as expected. You should follow the installation / upgrade instructions precisely to ensure both client and daemon are the same version.")
				}
			} else {
				if errors.Is(err, client.ErrNotFound) {
					logrus.Error("batt daemon is too old to report its version. You should follow the installation / upgrade instructions precisely to ensure both client and daemon are the same version.")
				}
			}

			if feature, required := requiredCapability(selected); required && !clientCapabilities.Supports(feature) {
				return fmt.Errorf("%s is not supported on this Mac", feature)
			}

			return nil
		},
	}
	defaultHelp := cmd.HelpFunc()
	cmd.SetHelpFunc(func(selected *cobra.Command, args []string) {
		hideUnsupportedCommands(selected.Root(), capabilitiesForHelp())
		defaultHelp(selected, args)
	})

	if os.Getenv("BATT_RUN_GUI") != "" || path.Base(os.Args[0]) == "batt-gui" {
		cmd.Run = func(_ *cobra.Command, _ []string) {
			gui.Run(unixSocketPath)
		}
	}

	// Direct cmd.Print* output to stdout instead of the default stderr.
	// This ensures normal command output (e.g., batt status) goes to stdout,
	// while only errors and diagnostics go to stderr.
	// See: https://github.com/charlie0129/batt/issues/120
	cmd.SetOut(os.Stdout)

	globalFlags := cmd.PersistentFlags()
	globalFlags.StringVarP(&logLevel, "log-level", "l", logLevel, "log level (trace, debug, info, warn, error, fatal, panic)")
	globalFlags.StringVar(&configPath, "config", configPath, "config file path")
	globalFlags.StringVar(&unixSocketPath, "daemon-socket", unixSocketPath, "batt daemon unix socket path")
	globalFlags.StringVar(&pprofAddr, "pprof", pprofAddr, "enable pprof HTTP server on the specified address (e.g., localhost:6060)")

	for _, i := range commandGroups {
		cmd.AddGroup(&cobra.Group{
			ID:    i,
			Title: i,
		})
	}

	cmd.AddCommand(
		NewDaemonCommand(),
		NewVersionCommand(),
		NewLimitCommand(),
		NewDisableCommand(),
		NewSetDisableChargingPreSleepCommand(),
		NewSetPreventIdleSleepCommand(),
		NewSetPreventSystemSleepCommand(),
		NewStatusCommand(),
		NewCalibrationCommand(),
		NewAdapterCommand(),
		NewLowerLimitDeltaCommand(),
		NewSetControlMagSafeLEDCommand(),
		NewInstallCommand(),
		NewUninstallCommand(),
		NewScheduleCommand(),
		gui.NewGUICommand(""),
	)

	return cmd
}
